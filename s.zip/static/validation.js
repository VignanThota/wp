function validate()
{
 var pass = document.getElementById("pass").value;
 var cpass = document.getElementById("cpass").value;
 if(pass==cpass)
 {
 	return document.getElementById("val")="Match successful";
 }
 else
 {
 	// console.log("mismatch")
 	return document.getElementById("val")="Password Mismatch";
 	// return false;
 }

}