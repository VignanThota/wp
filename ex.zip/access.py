from flask import *
from flask_sqlalchemy import SQLAlchemy
from flask import Flask, request, flash, url_for, redirect, render_template
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
app.secret_key = 'random string'
data = SQLAlchemy(app)

class Users(data.Model):
	__tablename__='user_accounts'
	email = data.Column(data.String(255),primary_key=True)
	password = data.Column(data.String(255))
	def __init__(self,email,password):
		self.email=email
		self.password=password
data.create_all()

@app.route('/')
def access():
	return render_template('index.html')
@app.route("/register",methods = ['GET','POST'])
def register():
	print("hello")
	if request.method =='POST':
		password = request.form['password']
		cpassword = request.form['cpassword']
		email = request.form['email']
		if exists(email):
			return render_template('index.html',error='Already Exists')
		if str(password)==str(cpassword):
			user = Users(email,password)
			data.session.add(user)
			data.session.commit() 
			return render_template('index.html',error='Registration Success')
		else:
			return render_template('index.html',error='password mismatch')
def exists(email):
	mail = "SELECT email FROM user_accounts"
	d = data.engine.execute(mail).fetchall()
	for i in d:
		if i[0] == email:
			return True
	return False
@app.route("/login",methods = ['GET','POST'])
def login():
	if request.method =='POST':
		password = request.form['password']
		email = request.form['email']
		c = "SELECT email, password FROM user_accounts"
		cred = data.engine.execute(c).fetchall()
		for i in cred:
			if i[0] == email and i[1] == password:
				session["user"] = email
				return render_template('success.html',success=email)
			else:
				return render_template('index.html',user='Something went wrong')
		else:
			return render_template('index.html',user='User not Exists')


@app.route("/logout",methods = ['GET','POST'])
def logout():
	if request.method =='POST':
		session.pop('email', None)
		data.session.close()
		return render_template('index.html')

	


if __name__=='__main__':
	app.run(host="127.0.0.1", port=int("8043"),debug=True)