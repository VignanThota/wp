package com.example.vignan.myprofileapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    String TAG=MainActivity.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String s = "";
        try {
            s = new com.example.vignan.myprofileapp.ViewCourseProfile().execute().get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            //            Log.w(TAG,"except");
            e.printStackTrace();
        }

        String[] data = getDatafromJson(s);
        //        Log.w(TAG,data[0]);
        ArrayAdapter a=new ArrayAdapter(this,R.layout.layout_item_profile,data);
        ListView b=findViewById(R.id.list_view);
        b.setAdapter(a);


    }
    private String[] getDatafromJson(String s)
    {
        ArrayList<String> st= new ArrayList<String>();
        JSONObject jsonObj;
        try {
            jsonObj  = new JSONObject(s);

            JSONArray contacts = jsonObj.getJSONArray("data");


            for (int i=0;i<contacts.length();i++)
            {  JSONObject c = contacts.getJSONObject(i);
                String course = "Course_id : "+c.getString("course_id");
                String subject  ="Subject : "+c.getString("course_name");
                String grade = "Grade :"+c.getString("grade");
                String Mentor = "Mentor : "+c.getString("mentor_name");
//                String application_number = "Application number : "+c.getString("application_number");
//                String blood_group = "Blood Group :"+c.getString("blood_group");
//                String student_mobile1 = "Mobile No : "+c.getString("student_mobile1");
//                String father_name = "Father Name :"+c.getString("father_name");
//                String ug_grade = "Ug_Grade :"+c.getString("ug_grade");
//                String last_updated = "last_updated :"+c.getString("last_updated");
//                String tenth_grade = "SSC Grade :"+c.getString("tenth_grade");
//                String intermediate_grade = "Inter_Grade :"+c.getString("intermediate_grade");
//                String qualifier_exam = "Qualifier_exam :"+c.getString("qualifier_exam");
//                String roll_number = "Roll_number :"+c.getString("roll_number");
//                String gat_critical_reading = "Gat_Critical Reading :"+c.getString("gat_critical_reading");
//                String quit = "quit :"+c.getString("quit");
//                String gat_quantitative_ability = "gat_quantitative_ability :"+c.getString("gat_quantitative_ability");
//                String user_type = "user_type :"+c.getString("user_type");
//                String father_mobile = "father_mobile :"+c.getString("father_mobile");
//                String ug_branch = "ug_branch :"+c.getString("ug_branch");
//                // String total_gat_score = "Total gat score:"c.getString("total_gat_score");
//                String student_fullname = "Full Name : "+c.getString("student_fullname");
//                String gat_writing = "gat_writing :"+c.getString("gat_writing");
//                String rank = "rank :"+c.getString("rank");
//                String student_email = "student_email :"+c.getString("student_email");
//                String gender = "gender :"+c.getString("gender");
                //   st.add(gat_critical_reading);
                st.add(course);
                st.add(subject);
                st.add(grade);
                st.add(Mentor);

//                st.add(gat_quantitative_ability);
//                st.add(gat_writing);
//                // st.add(total_gat_score);
//                st.add(student_fullname);
//                st.add(student_mobile1);
//                st.add(user_type);
//                st.add(qualifier_exam);
//                st.add(father_mobile);
//                st.add(ug_branch);
//                st.add(ug_grade);
//                st.add(roll_number);
//                st.add(intermediate_grade);
//                st.add(tenth_grade);
//                st.add(last_updated);
//                st.add(blood_group);
//                st.add(father_name);
//                st.add(application_number);
//                st.add(rank);
//                st.add(student_email);
//                st.add(gender);
            }



        } catch (JSONException e) {
            e.printStackTrace();
        }
        String[] s1 = new String[st.size()];
        s1 =  st.toArray(s1);
        return s1;
    }
}