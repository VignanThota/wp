from flask import *
from flask_sqlalchemy import SQLAlchemy
from flask import Flask, request, flash, url_for, redirect, render_template
app = Flask(__name__)
app.config['SQLALCHEMY_dbBASE_URI']='sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
app.secret_key = 'random string'
db = SQLAlchemy(app)

class Users(db.Model):
	__tablename__='users'
	email = db.Column(db.String(255),primary_key=True)
	password = db.Column(db.String(255))
	def __init__(self,email,password):
		self.email=email
		self.password=password
db.create_all()

@app.route('/')
def access():
	return render_template('Home.html')
@app.route("/register",methods = ['GET','POST'])
def register():
	print("hello")
	if request.method =='POST':
		password = request.form['password']
		cpassword = request.form['cpassword']
		email = request.form['email']
		if exists(email):
			return render_template('Home.html',error='Username already exists, please login')
		if str(password)==str(cpassword):
			user = Users(email,password)
			db.session.add(user)
			db.session.commit() 
			return render_template('Home.html',error='Successfully registered!!! Please login')
		else:
			return render_template('Home.html',error="Passwords didn't match")
def exists(email):
	mail = "SELECT email FROM users"
	data = db.engine.execute(mail).fetchall()
	for i in data:
		if i[0] == email:
			return True
	return False
@app.route("/login",methods = ['GET','POST'])
def login():
	if request.method =='POST':
		password = request.form['password']
		email = request.form['email']
		c = "SELECT email, password FROM users"
		da = db.engine.execute(c).fetchall()
		for i in da:
			if i[0] == email and i[1] == password:
				session["user"] = email
				return render_template('login.html',mail=email)
			else:
				return render_template('Home.html',user='Invalid UserId / Password')
		else:
			return render_template('Home.html',user='User does not Exist')


@app.route("/logout",methods = ['GET','POST'])
def logout():
	if request.method =='POST':
		session.pop('email', None)
		db.session.close()
		return render_template('Home.html')

if __name__=='__main__':
	app.run(host="127.0.0.1", port=int("9090"),debug=True)