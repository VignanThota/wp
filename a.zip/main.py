from flask import *
from flask_sqlalchemy import SQLAlchemy
from flask import Flask, request, flash, url_for, redirect, render_template

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
app.secret_key = 'random string'
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = set(['jpeg', 'jpg', 'png', 'gif'])
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
db = SQLAlchemy(app)

class Users(db.Model):
    __tablename__='users'
    email = db.Column(db.String(255),primary_key=True)
    password = db.Column(db.String(255))

    def __init__(self,email,password):
        self.email=email
        self.password=password
db.create_all()


@app.route("/")
def index():
	return render_template('login.html',error='')

@app.route("/login", methods = ['POST', 'GET'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        if is_valid(email, password):
            session['email'] = email
            return render_template('email.html',mail=email)
        else:
            error = 'Please check. Invalid UserId / Password'
            return render_template('email.html', mail=error)
@app.route("/logout")
def logout():
    session.pop('email', None)
    return redirect(url_for('login'))

def is_valid(email,password):
    stmt = "SELECT email, password FROM users"
    data = db.engine.execute(stmt).fetchall()
    for row in data:
        if row[0] == email and row[1] == password:
            return True
    return False

def exists(email):
    stmt = "SELECT email FROM users"
    data = db.engine.execute(stmt).fetchall()
    for row in data:
        if row[0] == email:
            return True
    return False
@app.route("/register",methods=['GET','POST'])
def register():
    if request.method =='POST':
        email = request.form['email']
        password = request.form['password']
        cpassword = request.form['cpassword']
        user=Users(email,password)
        if exists(email):
            error1='Username already exists, please login '
            return render_template('error.html',mail=error1)
        if (password!=cpassword):
            error2="Passwords didn't match "
            return render_template('error.html',mail=error2)
        else: 
            db.session.add(user)
            db.session.commit()          
            msg="Registration successfull"
             
    db.session.close()
    return render_template("login.html",msg=msg)
   
if __name__ =='__main__':
    
    app.run(debug=True,port=9090)


